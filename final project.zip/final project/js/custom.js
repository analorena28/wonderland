// Set the initial heights of the three main DIV's based on user window.
// Returns height of browser view port
var window = $(window).height();
$("header").css('min-height',window);	
